package com.example.myapplicationg

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Pestañas principales de navegación en la aplicación.
 */
enum class AppTab(val title: String, val icon: ImageVector) {
    GALERIA("Galería", Icons.Default.Collections),
    FAVORITOS("Favoritos", Icons.Default.Favorite),
    ELIMINADOS("Eliminados", Icons.Default.DeleteSweep)
}

/**
 * Enum para gestionar los filtros estéticos aplicables a las imágenes de Pokémon.
 */
enum class ImageFilter(val displayName: String, val colorMatrix: ColorMatrix?) {
    NORMAL("Normal", null),
    GRAYSCALE("Escala de Grises", ColorMatrix().apply { setToSaturation(0f) }),
    SEPIA("Sepia", ColorMatrix(floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))),
    INVERT("Invertido", ColorMatrix(floatArrayOf(
        -1f, 0f, 0f, 0f, 255f,
        0f, -1f, 0f, 0f, 255f,
        0f, 0f, -1f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f
    ))),
    HIGH_CONTRAST("Alto Contraste", ColorMatrix().apply { setToSaturation(2.0f) }),
    VINTAGE("Vintage", ColorMatrix(floatArrayOf(
        1.2f, 0.1f, 0.1f, 0f, 10f,
        0.1f, 1.0f, 0.1f, 0f, 5f,
        0.1f, 0.1f, 0.8f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))),
    COOL_CYAN("Azul Frío", ColorMatrix(floatArrayOf(
        0.5f, 0f, 0.5f, 0f, 0f,
        0f, 1.2f, 0.2f, 0f, 10f,
        0.2f, 0.2f, 1.5f, 0f, 20f,
        0f, 0f, 0f, 1f, 0f
    )))
}

/**
 * Modelo de datos para representar la información de cada Pokémon en la galería.
 */
data class PokemonItem(
    val id: Int,
    val pokedexNumber: String,
    val name: String,
    val type: String,
    val typeColorHex: Long,
    val imageUrl: String,
    var isFavorite: Boolean = false,
    var appliedFilter: ImageFilter = ImageFilter.NORMAL,
    var rotationAngle: Float = 0f,
    var customNickname: String = ""
)

/**
 * Provee la lista inicial de 12 Pokémon con ilustraciones oficiales.
 */
fun getInitialPokemonList(): List<PokemonItem> {
    return listOf(
        PokemonItem(
            id = 1,
            pokedexNumber = "#0001",
            name = "Bulbasaur",
            type = "Planta / Veneno",
            typeColorHex = 0xFF4CAF50,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png"
        ),
        PokemonItem(
            id = 4,
            pokedexNumber = "#0004",
            name = "Charmander",
            type = "Fuego",
            typeColorHex = 0xFFFF5722,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png"
        ),
        PokemonItem(
            id = 7,
            pokedexNumber = "#0007",
            name = "Squirtle",
            type = "Agua",
            typeColorHex = 0xFF2196F3,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png"
        ),
        PokemonItem(
            id = 25,
            pokedexNumber = "#0025",
            name = "Pikachu",
            type = "Eléctrico",
            typeColorHex = 0xFFFFC107,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png"
        ),
        PokemonItem(
            id = 133,
            pokedexNumber = "#0133",
            name = "Eevee",
            type = "Normal",
            typeColorHex = 0xFF8D6E63,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/133.png"
        ),
        PokemonItem(
            id = 143,
            pokedexNumber = "#0143",
            name = "Snorlax",
            type = "Normal",
            typeColorHex = 0xFF00897B,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/143.png"
        ),
        PokemonItem(
            id = 94,
            pokedexNumber = "#0094",
            name = "Gengar",
            type = "Fantasma / Veneno",
            typeColorHex = 0xFF7B1FA2,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/94.png"
        ),
        PokemonItem(
            id = 150,
            pokedexNumber = "#0150",
            name = "Mewtwo",
            type = "Psíquico",
            typeColorHex = 0xFFAB47BC,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png"
        ),
        PokemonItem(
            id = 448,
            pokedexNumber = "#0448",
            name = "Lucario",
            type = "Lucha / Acero",
            typeColorHex = 0xFF0288D1,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/448.png"
        ),
        PokemonItem(
            id = 658,
            pokedexNumber = "#0658",
            name = "Greninja",
            type = "Agua / Siniestro",
            typeColorHex = 0xFF1565C0,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/658.png"
        ),
        PokemonItem(
            id = 39,
            pokedexNumber = "#0039",
            name = "Jigglypuff",
            type = "Normal / Hada",
            typeColorHex = 0xFFEC407A,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/39.png"
        ),
        PokemonItem(
            id = 149,
            pokedexNumber = "#0149",
            name = "Dragonite",
            type = "Dragón / Volador",
            typeColorHex = 0xFFFB8C00,
            imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/149.png"
        )
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFFE53935), // Rojo Pokéball
                    secondary = Color(0xFF2B2B2B),
                    background = Color(0xFFF5F5F7)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PokemonGalleryApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PokemonGalleryApp() {
    val context = LocalContext.current

    // Pestaña actual seleccionada en la app
    var selectedTab by remember { mutableStateOf(AppTab.GALERIA) }

    // Lista principal de la Galería Activa
    val galeriaPrincipal = remember { mutableStateListOf<PokemonItem>().apply { addAll(getInitialPokemonList()) } }

    // Lista de Fotos Eliminadas (Papelera de reciclaje)
    val listaEliminados = remember { mutableStateListOf<PokemonItem>() }

    // Índice de la imagen visible en la Galería Principal
    var currentIndex by remember { mutableIntStateOf(0) }

    // Diálogos de acción
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    // Lista derivada de favoritos
    val listaFavoritos = galeriaPrincipal.filter { it.isFavorite }

    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    // Navegación: Imagen Anterior en la Galería Principal
    fun goToPrevious() {
        if (galeriaPrincipal.isNotEmpty()) {
            currentIndex = if (currentIndex > 0) currentIndex - 1 else galeriaPrincipal.size - 1
        }
    }

    // Navegación: Imagen Siguiente en la Galería Principal
    fun goToNext() {
        if (galeriaPrincipal.isNotEmpty()) {
            currentIndex = if (currentIndex < (galeriaPrincipal.size - 1)) currentIndex + 1 else 0
        }
    }

    // Acción Eliminar: quita de Galería Principal, añade a Papelera y ajusta el índice
    fun deleteCurrentPokemon() {
        if (galeriaPrincipal.isNotEmpty() && currentIndex in galeriaPrincipal.indices) {
            val removedPokemon = galeriaPrincipal[currentIndex]
            galeriaPrincipal.removeAt(currentIndex)
            listaEliminados.add(removedPokemon)

            // Ajustar el índice para no generar IndexOutOfBoundsException
            if (galeriaPrincipal.isNotEmpty()) {
                if (currentIndex >= galeriaPrincipal.size) {
                    currentIndex = galeriaPrincipal.size - 1
                }
            } else {
                currentIndex = 0
            }
            showToast("Se movió a ${removedPokemon.name} a 'Fotos Eliminadas'")
        }
    }

    // Acción Favoritos: marca o desmarca el Pokémon actual
    fun toggleFavorite() {
        if (galeriaPrincipal.isNotEmpty() && currentIndex in galeriaPrincipal.indices) {
            val current = galeriaPrincipal[currentIndex]
            val newFavState = !current.isFavorite
            galeriaPrincipal[currentIndex] = current.copy(isFavorite = newFavState)
            val msg = if (newFavState) "¡${current.name} agregado a Favoritos!" else "${current.name} quitado de Favoritos"
            showToast(msg)
        }
    }

    // Restaurar foto desde la Papelera a la Galería Principal
    fun restorePokemon(pokemon: PokemonItem) {
        listaEliminados.remove(pokemon)
        galeriaPrincipal.add(pokemon)
        showToast("${pokemon.name} restaurado a la Galería Principal")
    }

    // Eliminar definitivamente de la Papelera
    fun deletePermanently(pokemon: PokemonItem) {
        listaEliminados.remove(pokemon)
        showToast("${pokemon.name} eliminado definitivamente")
    }

    // Vaciar completamente la Papelera
    fun emptyTrash() {
        val count = listaEliminados.size
        listaEliminados.clear()
        showToast("Se eliminaron $count fotos de la papelera")
    }

    // Reiniciar y restaurar la galería original completa
    fun resetAll() {
        galeriaPrincipal.clear()
        galeriaPrincipal.addAll(getInitialPokemonList())
        listaEliminados.clear()
        currentIndex = 0
        showToast("Galería reiniciada al estado original")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFE53935),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color.White,
                                    modifier = Modifier.size(10.dp)
                                ) {}
                            }
                        }
                        Text(
                            text = when (selectedTab) {
                                AppTab.GALERIA -> "Galería Pokémon"
                                AppTab.FAVORITOS -> "Pokémon Favoritos"
                                AppTab.ELIMINADOS -> "Fotos Eliminadas"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { resetAll() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restaurar todo",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFD32F2F)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                AppTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    val badgeCount = when (tab) {
                        AppTab.GALERIA -> galeriaPrincipal.size
                        AppTab.FAVORITOS -> listaFavoritos.size
                        AppTab.ELIMINADOS -> listaEliminados.size
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (badgeCount > 0) {
                                        Badge(
                                            containerColor = if (tab == AppTab.FAVORITOS) Color(0xFFE91E63) else Color(0xFFD32F2F)
                                        ) {
                                            Text(text = badgeCount.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFD32F2F),
                            selectedTextColor = Color(0xFFD32F2F),
                            indicatorColor = Color(0xFFFFEBEE)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFF8F9FA), Color(0xFFE9ECEF))
                    )
                )
        ) {
            when (selectedTab) {
                AppTab.GALERIA -> {
                    // PESTAÑA 1: GALERÍA PRINCIPAL
                    if (galeriaPrincipal.isEmpty()) {
                        EmptyStateView(
                            title = "¡Galería de Pokémon Vacía!",
                            subtitle = "Todas las fotos fueron movidas a 'Fotos Eliminadas'.",
                            icon = Icons.Default.DeleteSweep,
                            buttonText = "Restaurar Galería Original",
                            onButtonClick = { resetAll() }
                        )
                    } else {
                        val safeIndex = currentIndex.coerceIn(0, galeriaPrincipal.size - 1)
                        val currentPokemon = galeriaPrincipal[safeIndex]

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Cabecera de la Imagen
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(currentPokemon.typeColorHex).copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, Color(currentPokemon.typeColorHex))
                                ) {
                                    Text(
                                        text = "${currentPokemon.pokedexNumber} - ${currentPokemon.customNickname.ifEmpty { currentPokemon.name }}",
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        fontWeight = FontWeight.Bold,
                                        color = Color(currentPokemon.typeColorHex),
                                        fontSize = 16.sp
                                    )
                                }

                                Text(
                                    text = "Foto ${safeIndex + 1} de ${galeriaPrincipal.size}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.Gray
                                )
                            }

                            // Imagen Principal con Flechas Laterales
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth(0.92f)
                                        .fillMaxHeight(0.92f)
                                        .shadow(12.dp, RoundedCornerShape(24.dp)),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.radialGradient(
                                                        colors = listOf(
                                                            Color(currentPokemon.typeColorHex).copy(alpha = 0.25f),
                                                            Color.White
                                                        )
                                                    )
                                                )
                                        )

                                        AnimatedContent(
                                            targetState = currentPokemon,
                                            transitionSpec = {
                                                fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                                            },
                                            label = "MainPokemonImage"
                                        ) { pokemon ->
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                AsyncImage(
                                                    model = ImageRequest.Builder(LocalContext.current)
                                                        .data(pokemon.imageUrl)
                                                        .crossfade(true)
                                                        .build(),
                                                    contentDescription = pokemon.name,
                                                    contentScale = ContentScale.Fit,
                                                    colorFilter = pokemon.appliedFilter.colorMatrix?.let { ColorFilter.colorMatrix(it) },
                                                    modifier = Modifier
                                                        .padding(24.dp)
                                                        .fillMaxSize(0.85f)
                                                        .rotate(pokemon.rotationAngle)
                                                )
                                            }
                                        }

                                        // Badges superiores sobre la foto
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.TopCenter)
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = Color(currentPokemon.typeColorHex)
                                            ) {
                                                Text(
                                                    text = currentPokemon.type,
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }

                                            if (currentPokemon.isFavorite) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = Color(0xFFE91E63)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Favorite,
                                                        contentDescription = "Favorito",
                                                        tint = Color.White,
                                                        modifier = Modifier
                                                            .padding(6.dp)
                                                            .size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Flechas de Navegación
                                FloatingActionButton(
                                    onClick = { goToPrevious() },
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(start = 4.dp)
                                        .size(48.dp),
                                    shape = CircleShape,
                                    containerColor = Color.White,
                                    contentColor = Color(0xFFD32F2F),
                                    elevation = FloatingActionButtonDefaults.elevation(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                                        contentDescription = "Anterior",
                                        modifier = Modifier.padding(start = 6.dp)
                                    )
                                }

                                FloatingActionButton(
                                    onClick = { goToNext() },
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(end = 4.dp)
                                        .size(48.dp),
                                    shape = CircleShape,
                                    containerColor = Color.White,
                                    contentColor = Color(0xFFD32F2F),
                                    elevation = FloatingActionButtonDefaults.elevation(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                        contentDescription = "Siguiente"
                                    )
                                }
                            }

                            // Barra de Miniaturas
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                itemsIndexed(galeriaPrincipal) { index, item ->
                                    val isSelected = index == safeIndex
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) Color(item.typeColorHex).copy(alpha = 0.2f) else Color.White)
                                            .border(
                                                width = if (isSelected) 2.5.dp else 1.dp,
                                                color = if (isSelected) Color(item.typeColorHex) else Color.LightGray,
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .clickable { currentIndex = index },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AsyncImage(
                                            model = item.imageUrl,
                                            contentDescription = item.name,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // 3 Botones de Acción Inferiores: "Editar", "Favorito", "Eliminar"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // 1. Botón "Editar"
                                Button(
                                    onClick = { showEditDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF1976D2),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    elevation = ButtonDefaults.buttonElevation(4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Editar",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Editar", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 2. Botón "Favoritos"
                                Button(
                                    onClick = { toggleFavorite() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (currentPokemon.isFavorite) Color(0xFFE91E63) else Color(0xFF757575),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    elevation = ButtonDefaults.buttonElevation(4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (currentPokemon.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                        contentDescription = "Favorito",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Favorito", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // 3. Botón "Eliminar"
                                Button(
                                    onClick = { showDeleteDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFD32F2F),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    elevation = ButtonDefaults.buttonElevation(4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(start = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Eliminar",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Eliminar", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                AppTab.FAVORITOS -> {
                    // PESTAÑA 2: SECCIÓN EXCLUSIVA DE FAVORITOS
                    if (listaFavoritos.isEmpty()) {
                        EmptyStateView(
                            title = "¡Sin Pokémon Favoritos!",
                            subtitle = "Marca tus Pokémon preferidos con el botón de corazón ❤️ en la Galería Principal.",
                            icon = Icons.Default.FavoriteBorder,
                            buttonText = "Ir a la Galería",
                            onButtonClick = { selectedTab = AppTab.GALERIA }
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Colección de Pokémon Favoritos (${listaFavoritos.size})",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF37474F),
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(listaFavoritos, key = { it.id }) { item ->
                                    Card(
                                        shape = RoundedCornerShape(18.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(4.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                // Al tocar, redirige a esa foto en la galería principal
                                                val targetIndex = galeriaPrincipal.indexOfFirst { it.id == item.id }
                                                if (targetIndex >= 0) {
                                                    currentIndex = targetIndex
                                                    selectedTab = AppTab.GALERIA
                                                }
                                            }
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .padding(12.dp)
                                                .fillMaxWidth(),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(110.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(item.typeColorHex).copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                AsyncImage(
                                                    model = item.imageUrl,
                                                    contentDescription = item.name,
                                                    colorFilter = item.appliedFilter.colorMatrix?.let { ColorFilter.colorMatrix(it) },
                                                    modifier = Modifier
                                                        .size(90.dp)
                                                        .rotate(item.rotationAngle)
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Text(
                                                text = item.customNickname.ifEmpty { item.name },
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            )

                                            Text(
                                                text = item.pokedexNumber,
                                                color = Color.Gray,
                                                fontSize = 12.sp
                                            )

                                            Spacer(modifier = Modifier.height(6.dp))

                                            IconButton(
                                                onClick = {
                                                    val idx = galeriaPrincipal.indexOfFirst { it.id == item.id }
                                                    if (idx >= 0) {
                                                        galeriaPrincipal[idx] = galeriaPrincipal[idx].copy(isFavorite = false)
                                                        showToast("Quitado de Favoritos")
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Favorite,
                                                    contentDescription = "Desmarcar favorito",
                                                    tint = Color(0xFFE91E63)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AppTab.ELIMINADOS -> {
                    // PESTAÑA 3: APARTADO DE FOTOS ELIMINADAS (PAPELERA)
                    if (listaEliminados.isEmpty()) {
                        EmptyStateView(
                            title = "Papelera Vacía",
                            subtitle = "No hay fotos eliminadas en este momento.",
                            icon = Icons.Default.DeleteSweep,
                            buttonText = "Ir a la Galería",
                            onButtonClick = { selectedTab = AppTab.GALERIA }
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Fotos Eliminadas (${listaEliminados.size})",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF37474F)
                                )

                                TextButton(onClick = { emptyTrash() }) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteForever,
                                        contentDescription = "Vaciar",
                                        tint = Color(0xFFD32F2F),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Vaciar Papelera", color = Color(0xFFD32F2F), fontWeight = FontWeight.Bold)
                                }
                            }

                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(listaEliminados, key = { it.id }) { item ->
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(3.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .padding(12.dp)
                                                .fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                AsyncImage(
                                                    model = item.imageUrl,
                                                    contentDescription = item.name,
                                                    modifier = Modifier
                                                        .size(54.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(item.typeColorHex).copy(alpha = 0.2f))
                                                )

                                                Column {
                                                    Text(
                                                        text = item.customNickname.ifEmpty { item.name },
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 16.sp
                                                    )
                                                    Text(
                                                        text = "${item.pokedexNumber} - ${item.type}",
                                                        fontSize = 12.sp,
                                                        color = Color.Gray
                                                    )
                                                }
                                            }

                                            Row {
                                                // Botón Restaurar
                                                IconButton(onClick = { restorePokemon(item) }) {
                                                    Icon(
                                                        imageVector = Icons.Default.RestoreFromTrash,
                                                        contentDescription = "Restaurar",
                                                        tint = Color(0xFF2E7D32)
                                                    )
                                                }

                                                // Botón Borrar Definitivamente
                                                IconButton(onClick = { deletePermanently(item) }) {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = "Borrar Definitivamente",
                                                        tint = Color(0xFFD32F2F)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- DIÁLOGO DE EDICIÓN BÁSICA Y FILTROS ---
    if (showEditDialog && galeriaPrincipal.isNotEmpty()) {
        val safeIdx = currentIndex.coerceIn(0, galeriaPrincipal.size - 1)
        val currentPkmn = galeriaPrincipal[safeIdx]
        var tempNickname by remember(currentPkmn) { mutableStateOf(currentPkmn.customNickname) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = "Editar",
                        tint = Color(0xFF1976D2)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Editar Foto - ${currentPkmn.name}")
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Edición de apodo/nombre personalizado
                    OutlinedTextField(
                        value = tempNickname,
                        onValueChange = { tempNickname = it },
                        label = { Text("Apodo personalizado") },
                        placeholder = { Text(currentPkmn.name) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Seleccionar Filtro Visual:",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    // Filtros estéticos
                    ImageFilter.entries.forEach { filter ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (currentPkmn.appliedFilter == filter) Color(0xFFE3F2FD) else Color.Transparent
                                )
                                .clickable {
                                    galeriaPrincipal[safeIdx] = currentPkmn.copy(appliedFilter = filter)
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = filter.displayName,
                                fontWeight = if (currentPkmn.appliedFilter == filter) FontWeight.Bold else FontWeight.Normal,
                                color = if (currentPkmn.appliedFilter == filter) Color(0xFF1976D2) else Color.Unspecified
                            )
                            if (currentPkmn.appliedFilter == filter) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Seleccionado",
                                    tint = Color(0xFF1976D2)
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Botón Rotar
                    Button(
                        onClick = {
                            val newAngle = (currentPkmn.rotationAngle + 90f) % 360f
                            galeriaPrincipal[safeIdx] = currentPkmn.copy(rotationAngle = newAngle)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F))
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Rotar")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Rotar 90° (${currentPkmn.rotationAngle.toInt()}°)")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        galeriaPrincipal[safeIdx] = currentPkmn.copy(customNickname = tempNickname)
                        showEditDialog = false
                        showToast("Cambios guardados para ${currentPkmn.name}")
                    }
                ) {
                    Text("Guardar Cambios")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showEditDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // --- DIÁLOGO DE CONFIRMACIÓN DE ELIMINACIÓN ---
    if (showDeleteDialog && galeriaPrincipal.isNotEmpty()) {
        val safeIdx = currentIndex.coerceIn(0, galeriaPrincipal.size - 1)
        val currentPkmn = galeriaPrincipal[safeIdx]

        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Advertencia",
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Mover a Fotos Eliminadas",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "¿Deseas quitar a ${currentPkmn.name} de la galería principal? Podrás restaurarlo después desde la pestaña 'Eliminados'.",
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        deleteCurrentPokemon()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text("Mover a Eliminados", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

/**
 * Componente genérico para estados vacíos de la aplicación.
 */
@Composable
fun EmptyStateView(
    title: String,
    subtitle: String,
    icon: ImageVector,
    buttonText: String,
    onButtonClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFECEFF1),
                    modifier = Modifier.size(90.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            modifier = Modifier.size(48.dp),
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF263238),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onButtonClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Acción")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = buttonText, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
